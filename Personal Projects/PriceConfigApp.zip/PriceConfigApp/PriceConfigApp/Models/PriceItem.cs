﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PriceConfigApp.Models
{
    public class PriceItem
    {
        public int PriceId { get; set; }
        public decimal Price { get; set; }
    }
}